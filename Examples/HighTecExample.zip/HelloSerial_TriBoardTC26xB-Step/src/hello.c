/*====================================================================
* Project:  Board Support Package (BSP) examples
* Function: example using a serial line (polling mode)
*
* Copyright HighTec EDV-Systeme GmbH 1982-2019
*====================================================================*/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "led.h"
#include "uart_poll.h"
#include "Benchmark.h"
#include "TaskDefinition.h"

#ifdef __TRICORE__
#if defined(__TC161__)
#include "system_tc2x.h"
#endif /* __TC161__ */
#if defined(__TC162__)
#include "system_tc3x.h"
#endif /* __TC162__ */
#endif /* __TRICORE__ */

#ifdef MINIMAL_CODE
#include "usr_sprintf.h"
#define SPRINTF		usr_sprintf
#define VSPRINTF	usr_vsprintf
#else
#define SPRINTF		sprintf
#define VSPRINTF	vsprintf
#endif /* MINIMAL_CODE */

#define BUFSIZE		128

#ifndef BAUDRATE
#define BAUDRATE	115200
#endif /* BAUDRATE */

static void my_puts(const char *str)
{
	char buffer[BUFSIZE];
	char *ptr;

	SPRINTF(buffer, "%s\r\n", str);

	for (ptr = buffer; *ptr; ++ptr)
		_out_uart((const unsigned char) *ptr);
}

static void my_printf(const char *fmt, ...)
{
	char buffer[BUFSIZE];
	char *ptr;
	va_list ap;

	va_start(ap, fmt);
	VSPRINTF(buffer, fmt, ap);
	va_end(ap);

	for (ptr = buffer; *ptr; ++ptr)
		_out_uart((const unsigned char) *ptr);
}

int fib(int n)
{
	return (n<1) ? n : fib(n-1) + fib(n-2);
}

TASK(task1)
{
	startTask(0,1);
	fib(10);
	finishTask(0);
}
TASK(task2)
{
	startTask(0,2);
	fib(10);
	finishTask(0);
}
TASK(task3)
{
	startTask(0,3);
	fib(10);
	finishTask(0);
}
TASK(task4)
{
	startTask(0,4);
	fib(10);
	finishTask(0);
}
TASK(task5)
{
	startTask(0,5);
	fib(10);
	finishTask(0);
}

int main(void)
{


#ifdef __TRICORE__
#if defined(__TC161__) || defined(__TC162__)
	SYSTEM_Init();
#endif /* __TC161__ || __TC162__ */
#endif /* __TRICORE__ */

	_init_uart(BAUDRATE);
	InitLED();
	volatile int i;

	initBenchmark();
	printCounters(&my_printf);
	startBenchmark();
	for (i=0; i<100; i++) CALL_TASK(task1);
	for (i=0; i<100; i++) CALL_TASK(task2);
	for (i=0; i<100; i++) CALL_TASK(task3);
	for (i=0; i<100; i++) CALL_TASK(task4);
	for (i=0; i<100; i++) CALL_TASK(task5);

	finishBenchmark();
	printCounters(&my_printf);

	LEDON(0);
	for(i=0; i<100000; i++);
	LEDOFF(0);



	return EXIT_SUCCESS;
}
