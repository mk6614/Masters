#include <basic_test.h>
#include <led.h>

MEASURE_TASK(Task1, 1)
{
	LEDON(0);
	volatile uint32_t i;
	for (i=0; i<200000; i++);
	LEDOFF(0);
}

MEASURE_TASK(Task2, 2)
{
	LEDON(1);
	volatile uint32_t i;
	for (i=0; i<200000; i++);
	LEDOFF(1);
}
MEASURE_TASK(Task4, 4)
{
	LEDON(3);
	volatile uint32_t i;
	for (i=0; i<200000; i++);
	LEDOFF(3);
}
MEASURE_TASK(Task5, 5)
{
	LEDON(4);
	volatile uint32_t i;
	for (i=0; i<200000; i++);
	LEDOFF(4);
}

void performBasicTest(void (*printf)(const char *fmt, ...))
{
	volatile uint32_t i;
	startBenchmark();
	for (i = 0; i<100; i++)
	{
		CALL_TASK(Task1);
		CALL_TASK(Task2);
	}
	for (i = 0; i<100; i++)
	{
		volatile uint32_t j;
		startTask(3);
		LEDON(2);
		for (j=0; j<200000; j++);
		LEDOFF(2);
		finishTask();
	}
	for (i = 0; i<100; i++)
	{
		CALL_TASK(Task4);
	}
	for (i = 0; i<100; i++)
	{
		CALL_TASK(Task5);
	}
	finishBenchmark();
	printCounters(printf);
}
