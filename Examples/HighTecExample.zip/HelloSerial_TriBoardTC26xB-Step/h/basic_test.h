/*
 * basic_test.h
 *
 *  Created on: 5 Dec 2020
 *      Author: mojca
 */

#ifndef BASIC_TEST_H_
#define BASIC_TEST_H_

#include "benchmark.h"

#define MEASURE_TASK(FunName, priority)	static void FunName(void); static void Task##FunName(void) { startTask(priority); FunName(); finishTask(); } static void FunName(void)
#define CALL_TASK(FunName)		Task##FunName();

void performBasicTest(void (*printf)(const char *fmt, ...));




#endif /* BASIC_TEST_H_ */
